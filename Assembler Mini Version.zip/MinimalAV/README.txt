=== AMV LANGUAGE REFERENCE ===

BASIC COMMANDS:
0x2 "text"     - Print text
1x2 "prompt"   - Input number → acc
2x2 "text"     - Print text with {acc}
3x1            - Exit program

MATH OPERATIONS:
4x3 + number   - Addition
4x3 - number   - Subtraction  
4x3 * number   - Multiplication
4x3 / number   - Division

VARIABLES:
5x4 variable   - Store acc to variable
6x4 variable   - Load variable to acc

CONTROL FLOW:
7x5 label      - Jump to label
8x6 op label   - Conditional jump
9x7            - Random number 0-99 → acc
