#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>

class AMVInterpreter {
private:
    std::unordered_map<std::string, double> variables;
    std::unordered_map<std::string, size_t> labels;
    std::vector<std::string> code_lines;
    double acc = 0;
    size_t pc = 0; // program counter
    
public:
    void run(const std::string& filename) {
        // Чтение и предобработка кода
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cout << "Error: Cannot open file " << filename << std::endl;
            return;
        }
        
        std::string line;
        while (std::getline(file, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') continue;
            
            // Поиск меток
            if (line.find(':') != std::string::npos) {
                std::string label = line.substr(0, line.find(':'));
                label = trim(label);
                labels[label] = code_lines.size();
            }
            
            code_lines.push_back(line);
        }
        file.close();
        
        // Выполнение программы
        while (pc < code_lines.size()) {
            executeCommand(code_lines[pc]);
            pc++;
        }
    }
    
    void executeCommand(const std::string& line) {
        if (line.empty() || line.find(':') != std::string::npos) return;
        
        std::istringstream iss(line);
        std::string command;
        iss >> command;
        
        try {
            if (command == "0x2") {
                printText(iss);
            }
            else if (command == "1x2") {
                inputText(iss);
            }
            else if (command == "2x2") {
                printWithAcc(iss);
            }
            else if (command == "3x1") {
                exit(0);
            }
            else if (command == "4x3") {
                mathOperation(iss);
            }
            else if (command == "5x4") {
                storeVariable(iss);
            }
            else if (command == "6x4") {
                loadVariable(iss);
            }
            else if (command == "7x5") {
                jumpToLabel(iss);
            }
            else if (command == "8x6") {
                conditionalJump(iss);
            }
            else if (command == "9x7") {
                randomNumber();
            }
            else if (command == "10x8") {
                compareNumbers(iss);
            }
            else {
                std::cout << "Unknown command: " << command << std::endl;
            }
        }
        catch (const std::exception& e) {
            std::cout << "Error in line: " << line << std::endl;
            std::cout << "Error: " << e.what() << std::endl;
        }
    }
    
private:
    void printText(std::istringstream& iss) {
        std::string text;
        std::getline(iss, text);
        text = trim(text);
        text = unquote(text);
        std::cout << text << std::endl;
    }
    
    void inputText(std::istringstream& iss) {
        std::string prompt;
        std::getline(iss, prompt);
        prompt = trim(prompt);
        prompt = unquote(prompt);
        std::cout << prompt;
        std::cin >> acc;
    }
    
    void printWithAcc(std::istringstream& iss) {
        std::string text;
        std::getline(iss, text);
        text = trim(text);
        text = unquote(text);
        
        size_t pos = text.find("{acc}");
        while (pos != std::string::npos) {
            text.replace(pos, 5, std::to_string(acc));
            pos = text.find("{acc}", pos + 1);
        }
        
        // Замена переменных
        for (const auto& var : variables) {
            std::string pattern = "{" + var.first + "}";
            size_t pos = text.find(pattern);
            while (pos != std::string::npos) {
                text.replace(pos, pattern.length(), std::to_string(var.second));
                pos = text.find(pattern, pos + 1);
            }
        }
        
        std::cout << text << std::endl;
    }
    
    void mathOperation(std::istringstream& iss) {
        std::string op;
        double num;
        iss >> op >> num;
        
        if (op == "+") acc += num;
        else if (op == "-") acc -= num;
        else if (op == "*") acc *= num;
        else if (op == "/") {
            if (num == 0) throw std::runtime_error("Division by zero");
            acc /= num;
        }
        else if (op == "%") {
            acc = static_cast<int>(acc) % static_cast<int>(num);
        }
    }
    
    void storeVariable(std::istringstream& iss) {
        std::string var;
        iss >> var;
        variables[var] = acc;
    }
    
    void loadVariable(std::istringstream& iss) {
        std::string var;
        iss >> var;
        if (variables.find(var) != variables.end()) {
            acc = variables[var];
        } else {
            throw std::runtime_error("Variable not found: " + var);
        }
    }
    
    void jumpToLabel(std::istringstream& iss) {
        std::string label;
        iss >> label;
        if (labels.find(label) != labels.end()) {
            pc = labels[label];
        } else {
            throw std::runtime_error("Label not found: " + label);
        }
    }
    
    void conditionalJump(std::istringstream& iss) {
        std::string op, label;
        iss >> op >> label;
        
        if (labels.find(label) == labels.end()) {
            throw std::runtime_error("Label not found: " + label);
        }
        
        bool condition = false;
        if (op == "==") condition = (acc == 0);
        else if (op == "!=") condition = (acc != 0);
        else if (op == ">") condition = (acc > 0);
        else if (op == "<") condition = (acc < 0);
        else if (op == ">=") condition = (acc >= 0);
        else if (op == "<=") condition = (acc <= 0);
        
        if (condition) {
            pc = labels[label];
        }
    }
    
    void randomNumber() {
        acc = rand() % 100;
    }
    
    void compareNumbers(std::istringstream& iss) {
        std::string var;
        iss >> var;
        if (variables.find(var) != variables.end()) {
            acc = variables[var] - acc;
        } else {
            throw std::runtime_error("Variable not found: " + var);
        }
    }
    
    std::string trim(const std::string& str) {
        size_t start = str.find_first_not_of(" \t");
        size_t end = str.find_last_not_of(" \t");
        return (start == std::string::npos) ? "" : str.substr(start, end - start + 1);
    }
    
    std::string unquote(const std::string& str) {
        if (str.length() >= 2 && 
            ((str.front() == '"' && str.back() == '"') || 
             (str.front() == '\'' && str.back() == '\''))) {
            return str.substr(1, str.length() - 2);
        }
        return str;
    }
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cout << "Usage: amv <filename.amv>" << std::endl;
        std::cout << "AMV - Assembler-like Minimalistic Language" << std::endl;
        return 1;
    }
    
    srand(time(0));
    AMVInterpreter interpreter;
    interpreter.run(argv[1]);
    
    return 0;
}
